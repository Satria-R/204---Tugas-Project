public class Ticket_Sriwijaya extends Ticket_Garuda{
    private String noTicket;
    private String HargaTicket;
    private String TanggalBerangkat;

    public void membeli (){

    }

    public String getNoTicket() {
        return noTicket;
    }

    public void setNoTicket(String noTicket) {
        this.noTicket = noTicket;
    }

    public String getHargaTicket() {
        return HargaTicket;
    }

    public void setHargaTicket(String hargaTicket) {
        HargaTicket = hargaTicket;
    }

    public String getTanggalBerangkat() {
        return TanggalBerangkat;
    }

    public void setTanggalBerangkat(String tanggalBerangkat) {
        TanggalBerangkat = tanggalBerangkat;
    }

    @Override
    public void dibeli() {
        super.dibeli();
    }

    @Override
    public void bookingTicket() {
        super.bookingTicket();
    }
}
