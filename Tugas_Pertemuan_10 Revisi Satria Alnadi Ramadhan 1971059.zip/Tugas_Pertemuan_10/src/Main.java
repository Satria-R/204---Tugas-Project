public class Main {
    public static void main(String[] args) {
        Ticket_Garuda Ticket1 = new Ticket_Garuda();
        Ticket_Garuda Ticket2 = new Ticket_Garuda();
        Ticket_Garuda Ticket3 = new Ticket_Garuda();
        Ticket_Garuda Ticket4 = new Ticket_Garuda();
        Ticket_Garuda Ticket5 = new Ticket_Garuda();
        Ticket_Garuda Ticket6 = new Ticket_Garuda();

        Ticket_Sriwijaya Adit = new Ticket_Sriwijaya("id 190887861" "Berangakat : Jakarta")
        Ticket_Sriwijaya Reza = new Ticket_Sriwijaya("id 190887843" "Berangakat : nusa 2")
        Ticket_Sriwijaya Reihan = new Ticket_Sriwijaya("id 1908872341" "Berangakat" : "Bandung")
        Ticket_Sriwijaya Pijun = new Ticket_Sriwijaya("id 190887414311" "Berangakat : Jakarta")
        Ticket_Sriwijaya Rahman = new Ticket_Sriwijaya("id 190887861232113" "Berangakat : Jakarta")

        Ticket_Sriwijaya TicketCargo = new Ticket_Sriwijaya();

    }
}
