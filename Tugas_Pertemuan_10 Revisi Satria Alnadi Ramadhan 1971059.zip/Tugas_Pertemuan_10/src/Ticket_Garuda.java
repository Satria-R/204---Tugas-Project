import java.util.Date;

public class Ticket_Garuda {
    private int noTicket;
    private String namaPenumpang;
    private String noPenerbangan;
    private String codeBooking;
    private Date tanggalKeberangkatan;
    private String masaBerlaku;
    private Date tanggalCekin;
    private String jenisTicket;

    //8 Attribut


    public Ticket_Garuda() {

    }

    public Ticket_Garuda(String codeBooking, String masaBerlaku, String jenisTicket) {
        this.codeBooking = codeBooking;
        this.masaBerlaku = masaBerlaku;
        this.jenisTicket = jenisTicket;
    }

    public void dibeli(){
        System.out.println("Ticket dibeli");
    }

    public void bookingTicket(){
        System.out.println("Ticket dipesan");

    }

    public void noPenerbangan(){
        System.out.println("mengambil noPenerbangan");
    }

    public void melakukanCekIn(){
        System.out.println("CekIn Ticket");
    }

    public int getNoTicket() {
        return noTicket;
    }

    public void setNoTicket(int noTicket) {
        this.noTicket = noTicket;
    }

    public String getNamaPenumpang() {
        return namaPenumpang;
    }

    public void setNamaPenumpang(String namaPenumpang) {
        this.namaPenumpang = namaPenumpang;
    }

    public String getNoPenerbangan() {
        return noPenerbangan;
    }

    public void setNoPenerbangan(String noPenerbangan) {
        this.noPenerbangan = noPenerbangan;
    }

    public String getCodeBooking() {
        return codeBooking;
    }

    public void setCodeBooking(String codeBooking) {
        this.codeBooking = codeBooking;
    }

    public Date getTanggalKeberangkatan() {
        return tanggalKeberangkatan;
    }

    public void setTanggalKeberangkatan(Date tanggalKeberangkatan) {
        this.tanggalKeberangkatan = tanggalKeberangkatan;
    }

    public String getMasaBerlaku() {
        return masaBerlaku;
    }

    public void setMasaBerlaku(String masaBerlaku) {
        this.masaBerlaku = masaBerlaku;
    }

    public Date getTanggalCekin() {
        return tanggalCekin;
    }

    public void setTanggalCekin(Date tanggalCekin) {
        this.tanggalCekin = tanggalCekin;
    }

    public String getJenisTicket() {
        return jenisTicket;
    }

    public void setJenisTicket(String jenisTicket) {
        this.jenisTicket = jenisTicket;
    }
}

