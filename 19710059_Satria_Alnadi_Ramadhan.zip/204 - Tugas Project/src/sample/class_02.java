package sample;

public class Pesawat_garuda {
    public static void  main(String [] args){
        // membuat objek


           pembeli tiket = new tiket();
        /* memanggil atribut dan memberi nilai */
                tiket.warna = "Biru";
                tiket.masaBerlaku = 21-04-2022;
           System.out.println("Warna: " + tiket.warna);
           system.out.println("tanggal": + tiket.masaBerlaku);
    }
}
