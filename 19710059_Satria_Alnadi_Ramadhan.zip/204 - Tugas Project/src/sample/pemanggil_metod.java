package sample;

// memberi nilai pada variabel
public class Persegi {
    public static void  main(String[] args) {


        Persegi PersegiPanjang= new Persegi();
        PersegiPanjang.lebar=10;
        PersegiPanjang.Panjang=25;

        //pemanggilan method hitungLuas
        Persegi.hitungLuas();

    }
}
