package sample;

public class Persegi {


    // membuat sebuah variabel
    Double luas;
    int sisi,sisi;


    // metod hitung luasnya
    void hitungLuas(){
        luas=sisi*sisi;
        System.out.println("Sisi        :"+ sisi);
        System.out.println("Sisi        :"+ sisi);
      System.out.println("Luas Persegi :" + luas);
    }

}
