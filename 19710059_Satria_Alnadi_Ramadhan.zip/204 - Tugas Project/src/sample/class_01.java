package sample;

public class Tiket_Pesawat { // calss nya
    String maskapai ;    // variabel nya di gunakan
    int hargaTicket;    // attribut yang digunakan
}
