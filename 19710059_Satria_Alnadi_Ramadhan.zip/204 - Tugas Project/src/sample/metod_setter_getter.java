package sample;

class pengguna {
    private String namapengguna;
    private String password;

    // kita gunakan metod setter
    public void setNamapengguna(String namapengguna){
        this.namapengguna = namapengguna;
    }

    public void setPassword(String password){
        this.password = password;
    }

    // ini metod getter
    public String getNamapengguna(){
        return this.namapengguna;
    }

    public String getPassword(){
        return this.password;
    }
}
